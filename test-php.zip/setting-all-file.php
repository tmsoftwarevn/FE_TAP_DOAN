<?php

require 'setting-language.php';

// $url_be = `https://belingo.tmsoftware.vn`




?>