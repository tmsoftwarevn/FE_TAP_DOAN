<div class="album-load"><button class="close-album close-format" aria-label="close"><svg><use xlink:href="#ico-close-menu"></use></svg> <span class="line-toggle toggle-1"></span> <span class="line-toggle toggle-2"></span></button>
    <div class="album-center">
        <div class="slidebox-track">
            <div class="slidebox-list">
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/274094608322112061145323329664450057903990n-2.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/274094608322112061145323329664450057903990n-2.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27416595332211218414531104959706605435760416n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27416595332211218414531104959706605435760416n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27418139232211216581197953591021285929255016n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27418139232211216581197953591021285929255016n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27420284432211212947864985592574003882416993n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27420284432211212947864985592574003882416993n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27421454432211218614531088577408847294352844n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27421454432211218614531088577408847294352844n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27422102532211227281196882820497200702639767n-2.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27422102532211227281196882820497200702639767n-2.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27424919232211216081198006975060717145054814n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27424919232211216081198006975060717145054814n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27426775532211218181197791667026352610095749n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27426775532211218181197791667026352610095749n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27427141832211216981197911335352606995326449n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27427141832211216981197911335352606995326449n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
                <div class="album-pic-center slidebox-item">
                    <div class="pic-name">
                        <h3> Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh.</h3>
                    </div>
                    <div class="container-zoom pinch-zoom"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27428633232211234047862872649121006574740721n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27428633232211234047862872649121006574740721n.jpg"
                            alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="thumbs">
        <div class="slidebox-track">
            <div class="slidebox-list">
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/274094608322112061145323329664450057903990n-2.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/274094608322112061145323329664450057903990n-2.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27416595332211218414531104959706605435760416n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27416595332211218414531104959706605435760416n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27418139232211216581197953591021285929255016n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27418139232211216581197953591021285929255016n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27420284432211212947864985592574003882416993n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27420284432211212947864985592574003882416993n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27421454432211218614531088577408847294352844n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27421454432211218614531088577408847294352844n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27422102532211227281196882820497200702639767n-2.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27422102532211227281196882820497200702639767n-2.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27424919232211216081198006975060717145054814n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27424919232211216081198006975060717145054814n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27426775532211218181197791667026352610095749n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27426775532211218181197791667026352610095749n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27427141832211216981197911335352606995326449n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27427141832211216981197911335352606995326449n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
                <div class="thumb-item slidebox-item"><img src="https://sengroup.vn/pictures/mobile/catalog/news/images/ket-noi-yeu-thuong/27428633232211234047862872649121006574740721n.jpg" data-src="https://sengroup.vn/pictures/catalog/news/images/ket-noi-yeu-thuong/27428633232211234047862872649121006574740721n.jpg"
                        alt=" Chương trình “Kết nối yêu thương” tại Trường Khiếm Thính Hy Vọng – Bình Thạnh." class="lazy"></div>
            </div>
        </div>
    </div>
</div>