<div class="video-list"><button class="close-video close-format" aria-label="close"><svg><use xlink:href="#ico-close-menu"></use></svg> <span class="line-toggle toggle-1"></span> <span class="line-toggle toggle-2"></span></button>
    <div class="video-wrap"> </div>
</div>