<?php

$lang = [];