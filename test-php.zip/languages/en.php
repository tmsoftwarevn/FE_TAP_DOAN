<!-- <?= __('Tìm kiếm') ?> -->

<?php

$lang = [
	'Tìm kiếm' => 'Search',
	'Lĩnh Vực' => 'Field of',
	'Hoạt Động' => "Activity"
	

];
